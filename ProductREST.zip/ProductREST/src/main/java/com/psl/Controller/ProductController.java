package com.psl.Controller;

import java.util.List;
import java.util.ListIterator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.portlet.ModelAndView;

import com.psl.Entity.Product;
import com.psl.Service.ProductService;

@Controller
public class ProductController {
	
	@Autowired
	private ProductService service;
	
	@RequestMapping(value="/Product/{pin}", method=RequestMethod.GET)
	public @ResponseBody Product getProduct(@PathVariable("pin") int pin){
		
		System.out.println("Inside Controller Index page..");
	
		Product p=service.display(pin);
		
		System.out.println(p);
		return p;
	}
	
	
	@RequestMapping(value = "/Product",method = RequestMethod.POST)
	public  @ResponseBody Product  addProduct(@RequestBody Product p)
	{
		service.addProduct(p);
		System.out.println("Product added ..");
		return p;
		
	}
	
	@RequestMapping(value="/Product",method = RequestMethod.PUT)
	public @ResponseBody Product updateProduct(@RequestBody Product p) {
		
		service.updateProduct(p);
		System.out.println("upadted");
		return p;
	}

}
