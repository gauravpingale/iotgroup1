package com.psl.Entity;

import java.util.Date;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="product")
public class Product {

	private int pin;
	private String productName;
	private String emptyDate;
	private int isEmpty;
	private String rackNo;
	private String sectionNo;
	private String cellNo;
	public Product() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Product(int pin, String productName, String emptyDate,
			int isEmpty, String rackNo, String sectionNo, String cellNo) {
		super();
		this.pin = pin;
		this.productName = productName;
		this.emptyDate = emptyDate;
		this.isEmpty = isEmpty;
		this.rackNo = rackNo;
		this.sectionNo = sectionNo;
		this.cellNo = cellNo;
	}
	public int getPin() {
		return pin;
	}
	public void setPin(int pin) {
		this.pin = pin;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getEmptyDate() {
		return emptyDate;
	}
	public void setEmptyDate(String emptyDate) {
		this.emptyDate = emptyDate;
	}
	public int isEmpty() {
		return isEmpty;
	}
	public void setEmpty(int isEmpty) {
		this.isEmpty = isEmpty;
	}
	public String getRackNo() {
		return rackNo;
	}
	public void setRackNo(String rackNo) {
		this.rackNo = rackNo;
	}
	public String getSectionNo() {
		return sectionNo;
	}
	public void setSectionNo(String sectionNo) {
		this.sectionNo = sectionNo;
	}
	public String getCellNo() {
		return cellNo;
	}
	public void setCellNo(String cellNo) {
		this.cellNo = cellNo;
	}
	@Override
	public String toString() {
		return "Product [pin=" + pin + ", productName=" + productName
				+ ", emptyDate=" + emptyDate + ", isEmpty=" + isEmpty
				+ ", rackNo=" + rackNo + ", sectionNo=" + sectionNo
				+ ", cellNo=" + cellNo + "]";
	}
	
	
}
