package com.psl.DAO;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.psl.Entity.Product;

public class ProductDAOImpl implements IProductDAO{

private JdbcTemplate jt;
	
	
	public JdbcTemplate getJt() {
		return jt;
	}


	public void setJt(JdbcTemplate jt) {
		this.jt = jt;
	}


	public Product display(int pin) {
		System.out.println("Inside DAOIMPL");

		/*String sql = "select * from product";

		List<Product> products = new ArrayList<Product>();

		List<Map<String, Object>> rows = getJt().queryForList(sql);
		for (Map row : rows) {
			Product p=new Product();
			p.setPin((Integer)row.get("pin"));
			p.setProductName((String)row.get("productName"));
			p.setEmptyDate((Date)row.get("emptyDate"));
			p.setEmpty((Boolean)row.get("isEmpty"));
			p.setRackNo((String)row.get("rackNo"));
			p.setSectionNo((String)row.get("sectionNo"));
			p.setCellNo((String)row.get("cellNo"));
			products.add(p);
			
			System.out.println(p);
		}

		System.out.println(products);
		return products;*/
		
     return jt.queryForObject("select * from product where pin="+pin,new RowMapper<Product>(){

			public Product mapRow(ResultSet rs, int arg1) throws SQLException {
				
				Product p=new Product();
				p.setPin(rs.getInt("pin"));
				p.setProductName(rs.getString("productName"));
				p.setEmptyDate(rs.getString("emptyDate"));
				p.setEmpty(rs.getInt("isEmpty"));
				p.setRackNo(rs.getString("rackNo"));
				p.setSectionNo(rs.getString("sectionNo"));
				p.setCellNo(rs.getString("cellNO"));
				return p;
			}
			
		});
	}


	
	public void addProduct(Product p) {
		// TODO Auto-generated method stub
		
		
			
		String sql="insert into product values("+p.getPin()+",'"+p.getProductName()+"','"+p.getEmptyDate()+"'," +p.isEmpty()+ " ,'"+p.getRackNo()+"','"+p.getSectionNo()+"','"+p.getCellNo()+"')";
		System.out.println("updated  "+sql);
		jt.update(sql);
		
	}



	public void updateProduct(Product p) {
		String sql="update product set emptyDate ='"+p.getEmptyDate()+"' where pin="+p.getPin();
		System.out.println("updated  "+sql);
		jt.update(sql);
		
	}


}
